import 'package:flutter/material.dart';

class Nav {
  const Nav({this.label, this.icon});

  final String label;
  final IconData icon;
}
