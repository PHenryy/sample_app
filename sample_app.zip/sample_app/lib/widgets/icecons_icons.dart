import 'package:flutter/widgets.dart';

class Icecons {
  Icecons._();

  static const _kFontFam = 'Icecons';

  static const IconData back = const IconData(0xe800, fontFamily: _kFontFam);
  static const IconData like = const IconData(0xe801, fontFamily: _kFontFam);
  static const IconData share = const IconData(0xe802, fontFamily: _kFontFam);
}
