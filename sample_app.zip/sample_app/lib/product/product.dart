class Product {
  Product({this.image, this.title, this.price, this.sales});

  final String image;
  final String title;
  final double price;
  final int sales;
}
